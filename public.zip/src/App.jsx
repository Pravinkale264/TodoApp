import ReconciliationDashboard from './components/ReconciliationDashboard';

function App() {
  return (
    <div className="App">
      <ReconciliationDashboard />
    </div>
  );
}

export default App;