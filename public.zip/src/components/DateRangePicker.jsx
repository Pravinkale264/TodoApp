const DateRangePicker = ({ startDate, endDate, onStartDateChange, onEndDateChange }) => {
  return (
    <div className="flex items-center gap-2">
      <span>is between</span>
      <input
        type="text"
        value={startDate}
        onChange={(e) => onStartDateChange(e.target.value)}
        className="border border-gray-300 rounded px-2 py-1 text-sm w-24"
      />
      <span>and</span>
      <input
        type="text"
        value={endDate}
        onChange={(e) => onEndDateChange(e.target.value)}
        className="border border-gray-300 rounded px-2 py-1 text-sm w-24"
      />
    </div>
  );
};

  export default DateRangePicker;