import { ChevronDown, Filter, RefreshCw } from "lucide-react";
import DateRangePicker from "../DateRangePicker";
import { useState } from "react";

const TransactionTable = ({ title, data, columns, hasSearch = true, hasDateFilter = false, filterStatus = null }) => {
  const [selectedRows, setSelectedRows] = useState([]);
  const [startDate, setStartDate] = useState('04/05/2025');
  const [endDate, setEndDate] = useState('04/07/2025');
  
  // Filter data based on status if filterStatus is provided
  const filteredData = filterStatus 
    ? data.filter(item => item.status === filterStatus)
    : data;
  
  const toggleSelectAll = () => {
    if (selectedRows.length === filteredData.length) {
      setSelectedRows([]);
    } else {
      setSelectedRows(filteredData.map(item => item.id));
    }
  };
  
  const toggleSelectRow = (id) => {
    if (selectedRows.includes(id)) {
      setSelectedRows(selectedRows.filter(rowId => rowId !== id));
    } else {
      setSelectedRows([...selectedRows, id]);
    }
  };
  
  return (
    <div className="border rounded-lg bg-white shadow-sm">
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center gap-2">
          <h3 className="font-medium">{title}</h3>
          <RefreshCw size={16} className="text-gray-400 cursor-pointer" />
        </div>
      </div>
      
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">Account:</span>
          <div className="relative">
            <select className="appearance-none border border-gray-300 rounded-md pl-3 pr-8 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option>Select an Account</option>
            </select>
            <ChevronDown size={16} className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </div>
        </div>
      </div>
      
      <div className="p-4 flex items-center justify-between border-b">
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1 text-sm border border-gray-300 rounded-md px-3 py-1">
            <span>Saved Searches</span>
            <ChevronDown size={14} />
          </button>
          {hasSearch && (
            <div className="relative">
              <input 
                type="text" 
                placeholder="Add filter..." 
                className="pl-3 pr-8 py-1 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <Filter size={14} className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
          )}
          {hasDateFilter && (
            <>
              <span className="text-sm">Date</span>
              <DateRangePicker 
                startDate={startDate}
                endDate={endDate}
                onStartDateChange={setStartDate}
                onEndDateChange={setEndDate}
              />
            </>
          )}
        </div>
        
        <div>
          <button className="p-1 border border-gray-300 rounded">
            <Filter size={16} className="text-gray-500" />
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-2 text-left">
                <input 
                  type="checkbox" 
                  checked={selectedRows.length === filteredData.length && filteredData.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded"
                />
              </th>
              {columns.map((column, index) => (
                <th key={index} className="px-4 py-2 text-left text-sm font-medium text-gray-500">
                  {column}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map((row) => (
                <tr key={row.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-2">
                    <input 
                      type="checkbox" 
                      checked={selectedRows.includes(row.id)}
                      onChange={() => toggleSelectRow(row.id)}
                      className="rounded"
                    />
                  </td>
                  {columns.map((column, index) => {
                    // Transform column name to match object property (e.g. 'Payment Reference' -> 'reference')
                    let key;
                    if (column === 'Payment Reference' || column === 'Transaction Id') {
                      key = column === 'Payment Reference' ? 'reference' : 'transactionId';
                    } else if (column === 'Payment Description' || column === 'Transaction Description') {
                      key = 'description';
                    } else {
                      key = column.toLowerCase();
                    }
                    
                    let value = row[key] || '';
                    
                    // Handle special cases for different columns
                    if (key === 'amount') {
                      const isNegative = value < 0;
                      value = isNegative ? value : `${value}`;
                    }
                    
                    return (
                      <td key={index} className="px-4 py-2 text-sm">
                        {value}
                      </td>
                    );
                  })}
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columns.length + 1} className="px-4 py-4 text-center text-gray-500">
                  No data available for this filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      
      {/* Add a conditional "Reconcile" button at the bottom if needed */}
      {filterStatus === 'notmatched' && (
        <div className="p-4 flex justify-end">
          <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md flex items-center gap-2">
            <div className="text-white">✓</div>
            <span>Reconcile</span>
          </button>
        </div>
      )}
    </div>
  );
};



  export default TransactionTable;