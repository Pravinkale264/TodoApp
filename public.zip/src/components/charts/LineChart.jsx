// const LineChart = ({ data, title }) => {
//   const maxUnmatched = Math.max(...data.map(item => item.unmatched));
//   const maxMatched = Math.max(...data.map(item => item.matched));
//   const maxValue = Math.max(maxUnmatched, maxMatched);
  
//   // Calculate points for SVG path
//   const matchedPoints = data.map((item, index) => {
//     const x = (index / (data.length - 1)) * 100;
//     const y = 100 - ((item.matched / maxValue) * 100);
//     return `${x},${y}`;
//   }).join(' ');
  
//   const unmatchedPoints = data.map((item, index) => {
//     const x = (index / (data.length - 1)) * 100;
//     const y = 100 - ((item.unmatched / maxValue) * 100);
//     return `${x},${y}`;
//   }).join(' ');
  
//   return (
//     <div className="border rounded-lg p-4 bg-white shadow-sm">
//       <h3 className="font-medium mb-4">{title}</h3>
//       <div className="h-56 relative">
//         <svg viewBox="0 0 100 100" className="w-full h-full">
//           {/* Grid lines */}
//           <line x1="0" y1="0" x2="100" y2="0" stroke="#e5e7eb" strokeWidth="0.5" />
//           <line x1="0" y1="25" x2="100" y2="25" stroke="#e5e7eb" strokeWidth="0.5" />
//           <line x1="0" y1="50" x2="100" y2="50" stroke="#e5e7eb" strokeWidth="0.5" />
//           <line x1="0" y1="75" x2="100" y2="75" stroke="#e5e7eb" strokeWidth="0.5" />
//           <line x1="0" y1="100" x2="100" y2="100" stroke="#e5e7eb" strokeWidth="0.5" />
          
//           {/* Lines */}
//           <polyline
//             fill="none"
//             stroke="#3b82f6"
//             strokeWidth="2"
//             points={matchedPoints}
//           />
//           <polyline
//             fill="none"
//             stroke="#ef4444"
//             strokeWidth="2"
//             points={unmatchedPoints}
//           />
          
//           {/* Points */}
//           {data.map((item, index) => {
//             const xMatched = (index / (data.length - 1)) * 100;
//             const yMatched = 100 - ((item.matched / maxValue) * 100);
//             const xUnmatched = (index / (data.length - 1)) * 100;
//             const yUnmatched = 100 - ((item.unmatched / maxValue) * 100);
            
//             return (
//               <g key={index}>
//                 <circle cx={xMatched} cy={yMatched} r="2" fill="#3b82f6" />
//                 <circle cx={xUnmatched} cy={yUnmatched} r="2" fill="#ef4444" />
//               </g>
//             );
//           })}
//         </svg>
        
//         {/* X-axis labels */}
//         <div className="flex justify-between mt-2">
//           {data.map((item, index) => (
//             <div key={index} className="text-xs text-gray-500">{item.day}</div>
//           ))}
//         </div>
//       </div>
      
//       {/* Legend */}
//       <div className="flex gap-4 mt-8 justify-center">
//         <div className="flex items-center">
//           <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
//           <span className="text-xs">Matched</span>
//         </div>
//         <div className="flex items-center">
//           <div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div>
//           <span className="text-xs">Unmatched</span>
//         </div>
//       </div>
//     </div>
//   );
// };

const LineChart = ({ data, title }) => {
  const maxUnmatched = Math.max(...data.map(item => item.unmatched));
  const maxMatched = Math.max(...data.map(item => item.matched));
  const maxValue = Math.max(maxUnmatched, maxMatched);

  const matchedPoints = data.map((item, index) => {
    const x = (index / (data.length - 1)) * 100;
    const y = 100 - ((item.matched / maxValue) * 100);
    return `${x},${y}`;
  }).join(' ');

  const unmatchedPoints = data.map((item, index) => {
    const x = (index / (data.length - 1)) * 100;
    const y = 100 - ((item.unmatched / maxValue) * 100);
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="border rounded-lg p-3 bg-white shadow-sm w-[270px] h-[240px] flex flex-col">
      <h3 className="font-medium mb-2 text-sm">{title}</h3>
      <div className="h-36 relative flex-1">
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <polyline fill="none" stroke="#3b82f6" strokeWidth="2" points={matchedPoints} />
          <polyline fill="none" stroke="#ef4444" strokeWidth="2" points={unmatchedPoints} />
          {data.map((item, index) => {
            const x = (index / (data.length - 1)) * 100;
            const y1 = 100 - ((item.matched / maxValue) * 100);
            const y2 = 100 - ((item.unmatched / maxValue) * 100);
            return (
              <g key={index}>
                <circle cx={x} cy={y1} r="2" fill="#3b82f6" />
                <circle cx={x} cy={y2} r="2" fill="#ef4444" />
              </g>
            );
          })}
        </svg>
        <div className="flex justify-between mt-1 text-[10px]">
          {data.map((item, idx) => (
            <span key={idx} className="text-gray-500">{item.day}</span>
          ))}
        </div>
      </div>
      <div className="flex gap-2 justify-center mt-4 text-[10px]">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-blue-500 rounded-full" />
          Matched
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 bg-red-500 rounded-full" />
          Unmatched
        </div>
      </div>
    </div>
  );
};


  export default LineChart;