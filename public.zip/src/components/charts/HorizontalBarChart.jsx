// const HorizontalBarChart = ({ data, title }) => {
//   const maxValue = Math.max(...Object.values(data));
  
//   return (
//     <div className="border rounded-lg p-4 bg-white shadow-sm">
//       <h3 className="font-medium mb-4">{title}</h3>
//       <div className="space-y-3">
//         {Object.entries(data).map(([key, value]) => (
//           <div key={key} className="flex items-center">
//             <div className="w-24 text-sm text-gray-600">{key}</div>
//             <div className="flex-1">
//               <div 
//                 className="bg-blue-500 h-6 rounded"
//                 style={{ width: `${(value / maxValue) * 100}%` }}
//               ></div>
//             </div>
//             <div className="w-10 text-right text-sm text-gray-600">{value}</div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

const HorizontalBarChart = ({ data, title }) => {
  const maxValue = Math.max(...Object.values(data));

  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm w-[270px] h-[240px] flex flex-col">
      <h3 className="font-medium mb-2 text-sm">{title}</h3>
      <div className="space-y-2 flex-1 overflow-auto">
        {Object.entries(data).map(([key, value]) => (
          <div key={key} className="flex items-center gap-2">
            <div className="w-20 text-[10px] text-gray-600 truncate">{key}</div>
            <div className="flex-1 bg-gray-100 rounded">
              <div
                className="bg-blue-500 h-4 rounded"
                style={{ width: `${(value / maxValue) * 100}%` }}
              />
            </div>
            <div className="w-8 text-[10px] text-right text-gray-600">{value}</div>
          </div>
        ))}
      </div>
    </div>
  );
};


  export default HorizontalBarChart;