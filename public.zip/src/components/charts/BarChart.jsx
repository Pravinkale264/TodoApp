// const BarChart = ({ data, title }) => {
//   const maxValue = Math.max(...Object.values(data));
  
//   return (
//     <div className="border rounded-lg p-4 bg-white shadow-sm">
//       <h3 className="font-medium mb-4">{title}</h3>
//       <div className="flex h-56 items-end gap-4">
//         {Object.entries(data).map(([key, value]) => (
//           <div key={key} className="flex flex-col items-center flex-1">
//             <div 
//               className="w-full bg-blue-500" 
//               style={{ 
//                 height: `${(value / maxValue) * 200}px`,
//               }}
//             ></div>
//             <span className="text-xs mt-2 text-gray-600 whitespace-nowrap">{key}</span>
//           </div>
//         ))}
//       </div>
//     </div>

//   );
// };

// const BarChart = ({ data, title }) => {
//   const maxValue = Math.max(...Object.values(data));

//   return (
//     <div className="border rounded-lg p-2 bg-white shadow-sm w-[300px] h-[280px] flex flex-col">
//       <h3 className="font-medium mb-2 text-sm">{title}</h3>
//       <div className="flex items-end gap-2 flex-1">
//         {Object.entries(data).map(([key, value]) => (
//           <div key={key} className="flex flex-col items-center flex-1">
//             <div
//               className="w-full bg-blue-500"
//               style={{ height: `${(value / maxValue) * 160}px` }} // Fits inside fixed height
//             ></div>
//             <span className="text-[10px] mt-1 text-gray-600 whitespace-nowrap">{key}</span>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

const BarChart = ({ data, title }) => {
  const maxValue = Math.max(...Object.values(data));

  return (
    <div className="border rounded-lg p-2 bg-white shadow-sm w-[270px] h-[240px] flex flex-col">
      <h3 className="font-medium mb-2 text-sm">{title}</h3>
      <div className="flex items-end justify-between flex-1">
        {Object.entries(data).map(([key, value]) => (
          <div key={key} className="flex flex-col items-center">
            <div
              className="bg-blue-500"
              style={{
                width: "48px", // 👈 set bar width here
                height: `${(value / maxValue) * 160}px`,
              }}
            ></div>
            <span className="text-[10px] mt-1 text-gray-600 whitespace-nowrap">{key}</span>
          </div>
        ))}
      </div>
    </div>
  );
};


  export default BarChart;

