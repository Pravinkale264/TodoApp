const StatusCard = ({ title, count, isActive, icon, onClick }) => {
  const baseClasses = "flex flex-col items-center justify-center p-4 rounded-lg shadow border cursor-pointer";
  const activeClasses = isActive
    ? "bg-blue-50 border-blue-300"
    : "bg-white border-gray-200 hover:bg-gray-50";

  return (
    <div className={`w-[200px] h-[150px] ${baseClasses} ${activeClasses}`} onClick={onClick}>
      <div className="flex items-center justify-between w-full">
        <h3 className="text-gray-700 font-medium text-sm">{title}</h3>
        <div className="w-6 h-6 flex items-center justify-center rounded-full bg-gray-100">
          {icon}
        </div>
      </div>
      <p className="text-3xl font-bold text-blue-500 self-start mt-1">{count}</p>
    </div>

  );
};

export default StatusCard;