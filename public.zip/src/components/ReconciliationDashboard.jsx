import { Moon, RefreshCw, Sun, X } from "lucide-react";
import BarChart from "./charts/BarChart";
import HorizontalBarChart from "./charts/HorizontalBarChart";
import LineChart from "./charts/LineChart";
import StatusCard from "./StatusCard";
import TransactionTable from "./tables/TransactionTable";
import { mockAccountTransactions, mockAgingData, mockBankTransactions, mockExceptionCategories, mockMatchedUnmatchedData } from "../data/mockData";
import { useState } from "react";

export default function ReconciliationDashboard() {
  const [darkMode, setDarkMode] = useState(false);
  const [activeStatusTab, setActiveStatusTab] = useState('notmatched'); // Default to 'notmatched'

  // Count items by status
  const reconciledCount = mockAccountTransactions.filter(item => item.status === 'reconciled').length;
  const matchedCount = mockAccountTransactions.filter(item => item.status === 'matched').length;
  const notMatchedCount = mockAccountTransactions.filter(item => item.status === 'notmatched').length;

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Function to handle status tab changes
  const handleStatusChange = (status) => {
    setActiveStatusTab(status);
  };

  // Function to get column configuration based on active tab
  const getColumns = () => {
    return ['Date', 'Type', 'Payment Description', 'Txn ID', 'Amount'];
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900 text-white' : 'bg-gray-100'}`}>
      {/* Header */}
      <header className="bg-white shadow-sm border-b flex items-center justify-between p-4">
        <div className="flex items-center h-10">
          <img
            src="https://awsmp-logos.s3.amazonaws.com/be75d721-6b47-4a26-bae8-d83f20fd9a29/a7da5b51dbf53e43f9198ca621163ba0.png"
            alt="logo"
            className="h-10 w-auto object-contain"
          />
        </div>
        <div className="flex items-center gap-4">
          <span className="font-medium">Sam</span>
          <div className="w-8 h-8 bg-gray-200 rounded-full overflow-hidden">
            <img src="https://img.freepik.com/free-vector/blue-circle-with-white-user_78370-4707.jpg?semt=ais_hybrid&w=740" alt="User avatar" />
          </div>
          {/* <button onClick={toggleDarkMode} className="p-1 rounded-full hover:bg-gray-100">
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button> */}
        </div>
      </header>

      {/* Dashboard content */}
      <main className="container mx-auto py-6 px-4">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-xl font-medium text-blue-500">Reconciliation Dashboard</h2>
        </div>

        {/* Charts Section */}
        {/* <div className="grid grid-cols-3 gap-6 mb-6">
          <BarChart 
            data={mockExceptionCategories} 
            title="Top Exception Categories" 
          />
          <LineChart 
            data={mockMatchedUnmatchedData} 
            title="Matched Vs Unmatched Transactions Overtime" 
          />
          <HorizontalBarChart 
            data={mockAgingData} 
            title="Aging of UnMatched Transactions" 
          />
        </div> */}

        {/* Status cards */}
        {/* <div className="grid grid-cols-3 gap-4 mb-6">
          <StatusCard 
            title="Reconciled" 
            count={reconciledCount} 
            isActive={activeStatusTab === 'reconciled'}
            icon={<RefreshCw size={16} className="text-blue-500" />}
            onClick={() => handleStatusChange('reconciled')}
          />
          <StatusCard 
            title="Fully Matched" 
            count={matchedCount} 
            isActive={activeStatusTab === 'matched'}
            icon={<div className="text-green-500">✓</div>}
            onClick={() => handleStatusChange('matched')}
          />
          <StatusCard 
            title="Not Matched" 
            count={notMatchedCount} 
            isActive={activeStatusTab === 'notmatched'}
            icon={<X size={16} className="text-red-500" />}
            onClick={() => handleStatusChange('notmatched')}
          />
        </div> */}

        <div className="flex gap-2 overflow-x-auto mb-6">
          {/* Charts */}
          <div className="flex bg-slate-300 rounded-lg p-2 gap-2">
            <div className="min-w-[270px]">
              <BarChart
                data={mockExceptionCategories}
                title="Top Exception Categories"
              />
            </div>
            <div className="min-w-[270px]">
              <LineChart
                data={mockMatchedUnmatchedData}
                title="Matched Vs Unmatched Transactions Overtime"
              />
            </div>
            <div className="min-w-[270px]">
              <HorizontalBarChart
                data={mockAgingData}
                title="Aging of UnMatched Transactions"
              />
            </div>
          </div>

          {/* Status Cards */}
          <div className="flex items-center rounded-lg bg-gray-300 p-2 gap-2 ml-1">
            <StatusCard
              title="Reconciled"
              count={reconciledCount}
              isActive={activeStatusTab === 'reconciled'}
              icon={<RefreshCw size={16} className="text-blue-500" />}
              onClick={() => handleStatusChange('reconciled')}
            />
            <StatusCard
              title="Fully Matched"
              count={matchedCount}
              isActive={activeStatusTab === 'matched'}
              icon={<div className="text-green-500">✓</div>}
              onClick={() => handleStatusChange('matched')}
            />
            <StatusCard
              title="Not Matched"
              count={notMatchedCount}
              isActive={activeStatusTab === 'notmatched'}
              icon={<X size={16} className="text-red-500" />}
              onClick={() => handleStatusChange('notmatched')}
            />
          </div>
        </div>


        {/* Tab indicator */}
        <div className="flex border-b mb-6">
          <div
            className={`pb-2 px-4 cursor-pointer ${activeStatusTab === 'reconciled' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => handleStatusChange('reconciled')}
          >
            Reconciled
          </div>
          <div
            className={`pb-2 px-4 cursor-pointer ${activeStatusTab === 'matched' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => handleStatusChange('matched')}
          >
            Fully Matched
          </div>
          <div
            className={`pb-2 px-4 cursor-pointer ${activeStatusTab === 'notmatched' ? 'border-b-2 border-blue-500 text-blue-500' : 'text-gray-500'}`}
            onClick={() => handleStatusChange('notmatched')}
          >
            Not Matched
          </div>
        </div>

        {/* Main transaction table - now filtered by status */}
        <TransactionTable
          title="Account Transaction Data"
          data={mockAccountTransactions}
          columns={getColumns()}
          filterStatus={activeStatusTab}
        />
      </main>
    </div>
  );
}