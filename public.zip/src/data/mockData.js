export const mockExceptionCategories = {
  missingData: 225,
  mismatch: 150,
  formattingIssue: 130
};

export const mockMatchedUnmatchedData = [
  { day: "May 1", matched: 230, unmatched: 260 },
  { day: "May 3", matched: 200, unmatched: 240 },
  { day: "May 5", matched: 240, unmatched: 270 },
  { day: "May 6", matched: 210, unmatched: 250 },
  { day: "May 7", matched: 220, unmatched: 260 },
  { day: "May 8", matched: 210, unmatched: 240 },
];

export const mockAgingData = {
  "0-1 days": 250,
  "2-3 days": 120,
  "4-7 days": 50,
  ">7 days": 20
};

// Enhanced mock data with reconciliation status
export const mockAccountTransactions = [
  { id: 1, date: '04/25/2025', reference: '127', description: 'Bill Payment', type: 'Bill Payment', amount: -90, status: 'notmatched' },
  { id: 2, date: '04/07/2025', reference: '225', description: 'BA funds', type: 'Bill Payments', amount: 36, status: 'notmatched' },
  { id: 3, date: '04/03/2025', reference: '2165', description: 'test', type: 'Debit', amount: -52, status: 'notmatched' },
  { id: 4, date: '04/10/2025', reference: '231', description: 'Added 2023443_1', type: 'Bill payment', amount: 32, status: 'reconciled' },
  { id: 5, date: '03/18/2025', reference: '743', description: 'Fund', type: 'Fund', amount: 16, status: 'notmatched' },
  { id: 6, date: '04/07/2025', reference: '225', description: 'BA funds', type: 'Bill Payments', amount: 36, status: 'notmatched' },
  { id: 7, date: '04/12/2025', reference: '246', description: 'Bill Payment', type: 'Bill Payment', amount: 66, status: 'notmatched' },
  { id: 8, date: '04/10/2025', reference: '240', description: 'WIRE FROM CITIBA', type: 'Transfer', amount: 55, status: 'reconciled' },
  { id: 9, date: '04/15/2025', reference: '301', description: 'Monthly Payment', type: 'Bill Payment', amount: 120, status: 'reconciled' },
  { id: 10, date: '04/18/2025', reference: '302', description: 'Subscription', type: 'Bill Payment', amount: 45, status: 'reconciled' },
  { id: 11, date: '04/20/2025', reference: '303', description: 'Utilities', type: 'Bill Payment', amount: 89, status: 'reconciled' },
  { id: 12, date: '04/22/2025', reference: '304', description: 'Insurance', type: 'Bill Payment', amount: 150, status: 'reconciled' },
  { id: 13, date: '04/05/2025', reference: '234', description: 'Vendor Payment', type: 'Transfer', amount: 210, status: 'matched' },
];

export const mockBankTransactions = [
  { id: 1, date: '04/05/2025', transactionId: '121545', description: 'wire from CitiBank NA', type: 'Transfer', amount: 25, status: 'notmatched' },
  { id: 2, date: '04/07/2025', transactionId: '36475', description: 'BA funds', type: 'Transfer', amount: 36, status: 'notmatched' },
  { id: 3, date: '04/05/2025', transactionId: 'TRN28464', description: 'debit', type: 'Transfer', amount: -56, status: 'matched' },
];